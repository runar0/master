import sim

class AppEventsStats:

  done = []
  period = 0

  def hook_application_start(self, appid):
  	if appid in self.done:
  		print '[BENCHMARK]', appid, 'restart'
  	else:
  		print '[BENCHMARK]', appid, 'start'

  def hook_application_exit(self, appid):
    if appid not in self.done:
    	print '[BENCHMARK]', appid, 'writing stats'    	
    	sim.stats.write('benchmark-%d-done' % appid)
    	self.done.append(appid)


  def setup(self, args):    

    args = args.split(':')

    if args[0] == 'periodic':
      self.period = (int) (args[1] if len(args) == 2 else 1000000000000)

      print '[PERIODIC] Periodic stats enabled (period %d)' % self.period
      sim.util.Every(self.period, self.periodic, roi_only = True)

  last_period = 0

  def periodic(self, time, delta):
    print '[PERIODIC] Writing periodic stats t=%d' % time
    sim.stats.write('periodic-%d' % time)



sim.util.register(AppEventsStats())