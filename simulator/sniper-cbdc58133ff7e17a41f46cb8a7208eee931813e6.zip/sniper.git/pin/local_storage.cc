#include "local_storage.h"

std::vector<ThreadLocalStorage> localStore(MAX_PIN_THREADS);
