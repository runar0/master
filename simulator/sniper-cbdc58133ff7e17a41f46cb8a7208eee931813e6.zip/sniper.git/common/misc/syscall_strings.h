#ifndef __SYSCALL_STRINGS
#define __SYSCALL_STRINGS

const char * syscall_string(int syscall_number);

#endif // __SYSCALL_STRINGS
